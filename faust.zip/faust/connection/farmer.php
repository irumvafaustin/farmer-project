
<html>
<head>

<style>
#customers {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 70%;
  margin:auto;
  margin-top:40px;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 16px 0px 16px 32px;
  font-size:30px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: center;
  font-size:30px;
  background-color: #04AA6D;
  color: white;
}
#customers a {
  float: left;
  color: white;
  font-weight:bold;
  text-align: center;
  padding: 2px 12px;
  text-decoration: none;
  font-size: 22px;
  border-radius: 2px 2px 2px 2px;
}
#customers a:hover {
  color: white;
  font-weight:bold;
  text-decoration:none;
}

#customers a:visited {
  color: white;
  font-weight:bold;
  text-decoration:none;
}
.danger
{
  background-color: red;
}
.change{
  background-color: blue;
}
.edit{
  background-color: green;
}
.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 26px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}
</style>

</head>
<body>


<header>
    <!-- <img class="logo" src="image/agrilogo.jpg"> -->
   
<div class="topnav">
<a href="MY PROJECT2.php">Home</a>
<a href="farmer.php">Farmer</a>
<a href="seller.php">Seller</a>
<a href="logout.php" style="float: right;">Logout</a>
</div>

<table id="customers">
  <tr>
    <th>#</th>
    <th>Firstname</th>
    <th>Lastname</th> 
    <th>Email</th>
    <th colspan="3">Action</th>
  </tr>
  <?php
$conn=mysqli_connect('localhost','root','','register');
$result=mysqli_query($conn,"select * from fregister");
?>
  <?php 
  $i=1;
  while($row=mysqli_fetch_array($result)):?>
  <tr>
    <td><?php echo $i++ ?></td>
    <td><?php echo $row['Fname'];?></td>
    <td><?php echo $row['Lname'];?></td>
    <td><?php echo $row['Email'];?></td>
   <td><a href="delete.php?id=<?php echo $row['id'] ?>" onclick="return confirm('Are you sure?')" class="danger">Delete</a></td>
   <td><a href="fupdate.php?id=<?php echo $row['id'] ?>" class="edit">Update</a></td>
   <td> <a href="farmerdetails.php?id=<?php echo $row['id'] ?>" class="change">View</td>
  </tr>
  <?php endwhile;?>
</table>
  </article>
  </section>
  <center>
    <footer class="footer text-center">
      <div class="footer-top">
        <div class="row">
          <div class="col-md-offset-3 col-md-6 text-center">
            <div class="widget">
              <h4 class="widget-title"> .</h4>
              <p><a href="#"><i class="fa fa-street-view" aria-hidden="true"></i></a> <b></b><br><a href="#"><i class="fa fa-map-marker" aria-hidden="true"></i></a><b> </b><br><br><a href="#"><i class="fa fa-envelope" aria-hidden="true"></i></a><b> </b><br><a href="#"><i class="fa fa-phone" aria-hidden="true"></i></a>  </p>
              
                <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
              
              <p class="copyright clear-float">
               
                <div class="credits">
                  
                  Designed by faustin</a>
                </div>
              </p>
            </div>
          </div>
        </div>
      </div>
    </footer>
    </center>
  </body>
  </html>
