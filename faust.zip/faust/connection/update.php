<?php
if(isset($_POST['update']))
{
$fname=$_POST['fname'];
$lname=$_POST['lname'];
$email=$_POST['email'];
$password=$_POST['password'];
$gender=$_POST['gender'];
$categories=$_POST['categories'];
$country=$_POST['country'];
$province=$_POST['slct1'];
$district=$_POST['slct2'];
$sector=$_POST['slct3'];
$cell=$_POST['slct4'];
$village=$_POST['slct5'];
$phone=$_POST['phone'];
$age=$_POST['age'];

$conn= new MySQLi('localhost','root','','register');

if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
$sql = "UPDATE fregister set fname='$fname',lname='$lname',email='$email',password='$password',gender='$gender',category='$categories',country='$country',provence='$province',district='$district',sector='$sector',cell='$cell',village='$village'";
if (mysqli_query($conn, $sql)) {
	echo "Successfully Registerd<br><br>";
  echo "<a href=flogin.php>Login Now</a>";
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
mysqli_close($conn);
}
?>