<?php
   include('config1.php'); 
	   ?>
	   <form action="productUpdat.php" method="post">
		  <input type="hidden" name ="id" value="<?php echo $_GET['id'] ?>" />
		  <br/>
         <input type="text" name ="pname"  placeholder="Enter the product name"/>
		  <br/> 		  
			<input type="number" name ="pquantity"  placeholder="Enter the price"/>
		   <br/> 
		   <input type="number" name ="pprice" placeholder="Enter the price"/>
		  <br/> 		  
			<input type="text" name ="file" placeholder="Enter image"/>
		   <br/> 
		   <input type="text" name ="pcategory" placeholder="Enter category"/>
		   <br/><input type="hidden" value="<?php echo $_GET['id'] ?>")/>
			<input type="submit" name ="update" value="Update"/>
			<input type="submit" name ="retrieve" value="Retrieve"/>
		</form> 	   
	   <?php  
	     if(isset($_POST['update'])){
			 echo "hello";
			 $pname = $_POST['pname'];
			 $id=$_POST['id'];
			 $pquantity = $_POST['pquantity'];
			 $pprice = $_POST['pprice'];
			 //$image = $_POST['image'];
			 $pcategory = $_POST['pcategory'];
			 $w = "UPDATE productivity SET productname='$pname', productquantity='$pquantity', productprice='$pprice', productcategory='$pcategory'
			 WHERE productid='$id'";
			 
			 $r = mysqli_query($connection,$w);
			 if(!$r){
				 echo "error ".mysqli_error($connection);
			 }
			 else{
				 echo "Updated successfully";
			 }
			 
		 }
?>