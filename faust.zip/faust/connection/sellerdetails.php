<?php
$conn=mysqli_connect('localhost','root','','register');
$query="select * from seller where sid=".$_GET['sid'];
$result=mysqli_query($conn, $query);
?>
<html>
<head>

<style>
#customers {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 50%;
  margin:auto;
  margin-top:40px;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 16px 0px 16px 32px;
  font-size:30px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: center;
  font-size:30px;
  background-color: #04AA6D;
  color: white;
}
.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 26px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}
</style>
</head>
<body>

<div class="topnav">
<a href="MY PROJECT2.php">Home</a>
<a href="farmer.php">Farmer</a>
<a href="seller.php">Seller</a>
<a href="logout.php" style="float: right;">Logout</a>
</div>

    <div>
<table id="customers"> 
    <th colspan="2"> Seller Details</th>
  <?php while($row=mysqli_fetch_array($result)):?>
    <tr> <td>ID</td><td><?php echo $row['sid'];?></td></tr>
    <tr> <td> Firstname</td><td> <?php echo $row['name'];?></td></tr>
    <tr>  <td>Email </td><td><?php echo $row['email'];?></td></tr>
    <tr> <td>Password</td><td> <?php echo $row['password'];?></td></tr>
   <tr>  <td>phone</td><td> <?php echo $row['phone'];?></td></tr>
   <tr> <td>age</td><td> <?php echo $row['age'];?></td></tr>
   <tr>  <td>category </td><td><?php echo $row['category'];?></td></tr>
   <tr>  <td>gender </td><td><?php echo $row['gender'];?></td></tr>
   <?php endwhile ?>
  </table>
  <center>
    <footer class="footer text-center">
      <div class="footer-top">
        <div class="row">
          <div class="col-md-offset-3 col-md-6 text-center">
            <div class="widget">
              <h4 class="widget-title"> .</h4>
              <p><a href="#"><i class="fa fa-street-view" aria-hidden="true"></i></a> <b></b><br><a href="#"><i class="fa fa-map-marker" aria-hidden="true"></i></a><b> </b><br><br><a href="#"><i class="fa fa-envelope" aria-hidden="true"></i></a><b> </b><br><a href="#"><i class="fa fa-phone" aria-hidden="true"></i></a>  </p>
              
                <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
              
              <p class="copyright clear-float">
               
                <div class="credits">
                  
                  Designed by faustin</a>
                </div>
              </p>
            </div>
          </div>
        </div>
      </div>
    </footer>
    </center>
  </body>
  </html>
