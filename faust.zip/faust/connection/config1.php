<?php
$_SERVER="127.0.0.1";
$user="root";
$pass="";
$db="register";
$connection=mysqli_connect($_SERVER,$user,$pass,$db);
if(!$connection)
{
echo "not passing";
}
