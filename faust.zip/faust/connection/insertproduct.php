<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "root", "", "register");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
// Escape user inputs for security
$code = mysqli_real_escape_string($link, $_REQUEST['']);
$name = mysqli_real_escape_string($link, $_REQUEST['']);
$quantity = mysqli_real_escape_string($link, $_REQUEST['']);
$unit_price = mysqli_real_escape_string($link, $_REQUEST['']);
$price = mysqli_real_escape_string($link, $_REQUEST['']);
 
// Attempt insert query execution
$sql = "INSERT INTO user (email,password) VALUES ('$email','$password')";
if(mysqli_query($link, $sql)){
    echo "Records added successfully.";
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// Close connection
mysqli_close($link);
?>