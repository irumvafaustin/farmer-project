<?php

$firstname=$_POST['firstname'];
$lastname=$_POST['lastname'];
$email=$_POST['email'];
$message=$_POST['message'];
$conn= new MySQLi('localhost','root','','register');

if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
$sql = "INSERT INTO contact( `firstname`, `lastname`, `email`, `message`)
VALUES ('$firstname','$lastname','$email','$message')";

if (mysqli_query($conn, $sql)) {
	echo "Your message has been recived<br><br>";
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
?>