<?php
session_start();
?>
<html>
<head>
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  margin: 0;
}

.navbar {
  overflow: hidden;
  background-color: #333; 
}

.navbar a {
  float: left;
  font-size: 16px;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

.subnav {
  float: left;
  overflow: hidden;
}

.subnav .subnavbtn {
  font-size: 16px;  
  border: none;
  outline: none;
  color: white;
  padding: 14px 16px;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
}

.navbar a:hover, .subnav:hover .subnavbtn {
  background-color: green;
}

.subnav-content {
  display: none;
  position: absolute;
  left: 0;
  background-color: DarkSlateBlue;
  width: 100%;
  z-index: 1;
}

.subnav-content a {
  float: left;
  color: white;
  text-decoration: none;
}

.subnav-content a:hover {
  background-color: #eee;
  color: black;
}

.subnav:hover .subnav-content {
  display: block;
}

article {
  float: left;
  padding: 20px;
  width: 100%;
  background-color: #f1f1f1;
  height: 300px;
}
.footer {
  text-align: center;
  padding: 3px;
  background-color: #ccc;
  color: white;
  width:100%;
}
* {
  box-sizing: border-box;
}
.column {
  float: left;
  width: 33.33%;
  padding: 10px;
  height: 300px;
  background-color:red;
}
.row:after {
  content: "";
  display: table;
  clear: both;
}
h2{
color:red;
text-align:center;
}
.btn:hover {
      transform: scale(1.03);
      }
      .btn span {
      font-size: 16px;
      }
      .facebook {
      background: #3a589e;
      }
      .twitter {
      background: #429cd6;
      }
      .google{
      background: #d34836;
      }
      .p{
        text-decoration: none;
      }
</style>
</head>
<body>

<header>
  <h2>AGRICULTURE</h2>
</header>


<div class="navbar">
  <a href="MY PROJECT2.php">Home</a>
  <div class="subnav">
    <button class="subnavbtn">FARMER <i class="fa fa-caret-down"></i></button>
    <div class="subnav-content">
      <a href="fregister.php">REGISTER</a>
      <a href="index.php">PRODUCTIVITY</a>
	  <a href="flogin.php">LOGIN</a>
    </div>
  </div> 
  <div class="subnav">
    <button class="subnavbtn">SELLER<i class="fa fa-caret-down"></i></button>
    <div class="subnav-content">
      
    <a href="prod.html">online service</a>
    <a href="sregister.php">REGISTER</a>
      <a href="slogin.php">LOGIN</a>
    </div>
  </div> 
  <div class="subnav">
    <button class="subnavbtn">ADMIN <i class="fa fa-caret-down"></i></button>
    <div class="subnav-content">
      <a href="adminlogin.php">LOGIN</a>
      
    </div>
    </div>
    <div class="subnav">
      <?php 
      if(isset($_SESSION['user'])) 
      {
        echo '<button class="subnavbtn"> <a href="logout.php">LOGOUT<i class="fa fa-caret-down"></i></a></button>';
      }       
      ?>
  </div>
</div>
<div>
<article >
  <h3>WELCOME TO OUR WEBSITE</h3>
  <h3>THAT SHOWS YOU HOW THE MODERN AGRICULTURE.</h3>
  <h3>CAN HELP YOU TO TAKE INFORMATION ABOUT YOUR ACTIVITIES</h3>
</article >
</div>
  <div>
  <img src="rwanda.png"width="1500"height="800"/>
  </div>
  <div class="footer">
  <div class="column" style="background-color:#ccc;">
    <h2>ABOUT US</h2>
    <p><a href="contact.php">CONTACT</a></p><BR>
	
  </div>
   <div class="column" style="background-color:#ccc;">
    <h2>PARTNERS</h2>
    <p>RAB</p>
	<p>RSSB</p>
  </div>
  <div class="column" style="background-color:#ccc;">
    <h2>FOLLOW US</h2>
      <div class="block-item right">
        <button class="btn facebook" data-provider="facebook"><i class="fab fa-facebook-f"></i><span>Facebook</span></button>
        <button class="btn twitter" data-provider="twitter"><i class="fab fa-twitter"></i><span>Twitter</span></button>
        <button class="btn google" data-provider="google"><i class="fab fa-google"></i><span>Google</span></button>
      </div>
  </div>
</div>
</div>
</body>
</html>
