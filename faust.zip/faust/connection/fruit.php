
<html>
    <head>
    
    
    <script type="text/javascript">
    function call()
    {
    var name=prompt("The pair of shoes is 9000 rwf Please enter number of pairs yo want","");
    if (name!=null && name!="")
    {
    var r=confirm("The  "+name+" pairs you choosen="+name*9000+" click ok to buy now");
    if (r==true)
    {
    document.write("<a href='buy.html'>fill the form of payment</a>");
    }
    else
    {
    return false
    }
    }
    }
    
    </script>
    <script type="text/javascript">
    function first()
    {
    var name=prompt("The pair of shoes is 11000 rwf Please enter number of pairs yo want","");
    if (name!=null && name!="")
    {
    var r=confirm("The  "+name+" pairs you choosen="+name*11000+" click ok to buy now");
    if (r==true)
    {
    document.write("<a href='buy.html'>fill the form of payment</a>");
    }
    else
    {
    return false
    }
    }
    }
    
    </script>
    <script type="text/javascript">
    function second()
    {
    var name=prompt("The pair of shoes is 10000 rwf Please enter number of pairs yo want","");
    if (name!=null && name!="")
    {
    var r=confirm("The  "+name+" pairs you choosen="+name*10000+" click ok to buy now");
    if (r==true)
    {
    document.write("<a href='buy.html'>fill the form of payment</a>");
    }
    else
    {
    return false
    }
    }
    }
    
    </script>
    <script type="text/javascript">
    function third()
    {
    var name=prompt("The pair of shoes is 7000 rwf Please enter number of pairs yo want","");
    if (name!=null && name!="")
    {
    var r=confirm("The  "+name+" pairs you choosen="+name*7000+" click ok to buy now");
    if (r==true)
    {
    document.write("<a href='buy.html'>fill the form of payment</a>");
    }
    else
    {
    return false
    }
    }
    }
    
    </script>
    <script type="text/javascript">
    function four()
    {
    var name=prompt("The pair of shoes is 10000 rwf Please enter number of pairs yo want","");
    if (name!=null && name!="")
    {
    var r=confirm("The  "+name+" pairs you choosen="+name*10000+" click ok to buy now");
    if (r==true)
    {
    document.write("<a href='buy.html'>fill the form of payment</a>");
    }
    else
    {
    return false
    }
    }
    }
    
    </script>
    <script type="text/javascript">
    function five()
    {
    var name=prompt("The pair of shoes is 8000 rwf Please enter number of pairs yo want","");
    if (name!=null && name!="")
    {
    var r=confirm("The  "+name+" pairs you choosen="+name*8000+" click ok to buy now");
    if (r==true)
    {
    document.write("<a href='buy.html'>fill the form of payment</a>");
    }
    else
    {
    return false
    }
    }
    }
    
    </script>
    <script type="text/javascript">
    function six()
    {
    var name=prompt("The pair of shoes is 13000 rwf Please enter number of pairs yo want","");
    if (name!=null && name!="")
    {
    var r=confirm("The  "+name+" pairs you choosen="+name*13000+" click ok to buy now");
    if (r==true)
    {
    document.write("<a href='buy.html'>fill the form of payment</a>");
    }
    else
    {
    return false
    }
    }
    }
    
    </script>
    <script type="text/javascript">
    function seven()
    {
    var name=prompt("The pair of shoes is 13000 rwf Please enter number of pairs yo want","");
    if (name!=null && name!="")
    {
    var r=confirm("The  "+name+" pairs you choosen="+name*13000+" click ok to buy now");
    if (r==true)
    {
    document.write("<a href='buy.html'>fill the form of payment</a>");
    }
    else
    {
    return false
    }
    }
    }
    
    </script>
    <script type="text/javascript">
    function nine()
    {
    var name=prompt("The pair of shoes is 10000 rwf Please enter number of pairs yo want","");
    if (name!=null && name!="")
    {
    var r=confirm("The  "+name+" pairs you choosen="+name*10000+" click ok to buy now");
    if (r==true)
    {
    document.write("<a href='buy.html'>fill the form of payment</a>");
    }
    else
    {
    return false
    }
    }
    }
    
    </script>
    <script type="text/javascript">
    function ten()
    {
    var name=prompt("The pair of shoes is 11000 rwf Please enter number of pairs yo want","");
    if (name!=null && name!="")
    {
    var r=confirm("The  "+name+" pairs you choosen="+name*11000+" click ok to buy now");
    if (r==true)
    {
    document.write("<a href='buy.html'>fill the form of payment</a>");
    }
    else
    {
    return false
    }
    }
    }
    
    </script>
    <script type="text/javascript">
    function one()
    {
    var name=prompt("The pair of shoes is 15000 rwf Please enter number of pairs yo want","");
    if (name!=null && name!="")
    {
    var r=confirm("The  "+name+" pairs you choosen="+name*15000+" click ok to buy now");
    if (r==true)
    {
    document.write("<a href='buy.html'>fill the form of payment</a>");
    }
    else
    {
    return false
    }
    }
    }
    
    </script>
    </head>
    <body>
    <table  width="100%">
    <tr>
        <td width="70%"> <h1><b>CHOOSE ANTIDEPRESSANTS MAKE GROW IN AGRICULTURE</b></h1>
        <td><h1>BUY NOW<h1></td>
    </tr>
    </table><table width="100%"
    <tr>
        <td><img src="millmax.jpg" width="200" height="251" border="0" alt=""></td><form><input type="button" value="Yes" onclick="call()"/></form>
        <td><img src="D&IGROW.jpg" width="275" height="183" border="0" alt=""><input type="button" value="Yes" onclick="first()"></td>
        <td><img src="ingabo.jpg" width="200" height="251" border="0" alt=""><input type="button" value="Yes" onclick="second()"></td>
        <td><img src="VIGMAX.jpg" width="225" height="225" border="0" alt=""><input type="button" value="Yes" onclick="third()"></td>
    </tr>
    <tr>
        <td><img src="TOYO.jpg" width="265" height="190" border="0" alt=""><input type="button" value="Yes" onclick="four()"></td>
        <td><img src="poly_feed.jpg" width="254" height="198" border="0" alt=""><input type="button" value="Yes" onclick="five()"></td>
        <td><img src="kisangrow.jpg" width="272" height="185" border="0" alt=""><input type="button" value="Yes" onclick="six()"></td>
        <td><img src="digrow.jpg" width="275" height="183" border="0" alt=""><input type="button" value="Yes" onclick="seven()"></td>
    </tr>
    <tr>
        <td><img src="oll/images (7).jpg" width="225" height="225" border="0" alt=""><input type="button" value="Yes" onclick="nine()"></td>
        <td><img src="oll/images (6).jpg" width="248" height="203" border="0" alt=""><input type="button" value="Yes" onclick="ten()"></td>
        <td><img src="oll/images (8).jpg" width="275" height="183" border="0" alt=""><input type="button" value="Yes" onclick="one()"></td>
    </tr>	
    </table>
    </body></html>
    
    
    
    
    
    
    
    
    
    
    
    