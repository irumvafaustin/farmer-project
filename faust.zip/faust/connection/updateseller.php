<?php
if(isset($_POST['update']))
{
$firstname=$_POST['firstname'];
$lastname=$_POST['lastname'];
$email=$_POST['email'];
$message=$_POST['message'];

$conn= new MySQLi('localhost','root','','register');

if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
$sql = "UPDATE seller set firstname='$firstname',lastname='$lastname',email='$email',message='$message'";
if (mysqli_query($conn, $sql)) {
	echo "Successfully Registerd<br><br>";
  echo "<a href=flogin.php>Login Now</a>";
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
mysqli_close($conn);
}
?>