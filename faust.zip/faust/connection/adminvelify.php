<?php


$username=$_POST['email'];
$password=$_POST['password'];
$conn= new MySQLi('localhost','root','','register');

if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

else{
	$stmt=$conn->prepare("select * from admin where adminemail=? AND adminpassword=? ");
	$stmt->bind_param("ss",$username,$password);
	$stmt->execute();
	$stmt_result=$stmt->get_result();
	if($stmt_result->num_rows>0){
		$data=$stmt_result->fetch_assoc();
	
		echo '<script>
		window.location="farmer.php";
		</script>';
	
}
	else{
		echo '<script>
         alert("Wrong Email or Password");
		</script>';
		
	}

}

?>
	