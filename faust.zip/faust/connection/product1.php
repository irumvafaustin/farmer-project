<?php
$conn=mysqli_connect('localhost','root','','register');
$result=mysqli_query($conn,"select * from productivity");
?>
<html>
<head>
<script type="text/javascript">
function delete_id(id)
{
 if(confirm('Are you sure you want to remove this record ?'))
 {
  window.location.href='delete1.php?delete_id='+id;
 }
}
</script>

<style>
  .navbar {
  overflow: hidden;
  background-color: #333; 
}

.navbar a {
  float: left;
  font-size: 16px;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

.subnav {
  float: left;
  overflow: hidden;
}

.subnav .subnavbtn {
  font-size: 16px;  
  border: none;
  outline: none;
  color: white;
  padding: 14px 16px;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
}

.navbar a:hover, .subnav:hover .subnavbtn {
  background-color: green;
}

.subnav-content {
  display: none;
  position: absolute;
  left: 0;
  background-color: skyblue;
  width: 100%;
  z-index: 1;
}

.subnav-content a {
  float: left;
  color: white;
  text-decoration: none;
}

.subnav-content a:hover {
  background-color: #eee;
  color: black;
}

.subnav:hover .subnav-content {
  display: block;
}
    table {
      border:1px;
    border-collapse: collapse;
    width: 100%;
    background-color:#skyblue;
  }
  
  th, td {
    text-align: left;
    padding: 8px;
    border-radius: 25px;
    background-color:#skyblue;
  }
  tr:nth-child(even) {background-color:white;}
</style>

</head>
<body>


<header>
    <h2><img class="logo" src="agrilogo.jpg">agriculture</h2>
</header>

<div class="navbar">
  <a href="MY PROJECT2.php">Home</a>
  <div class="subnav">
    <button class="subnavbtn">FARMER <i class="fa fa-caret-down"></i></button>
    <div class="subnav-content">
      <a href="fregister.php">REGISTER</a>
      <a href="product1.php">PRODACTIVITY</a>
	  <a href="flogin.php">LOGIN</a>
    </div>
  </div> 
  <div class="subnav">
    <button class="subnavbtn">SELLER<i class="fa fa-caret-down"></i></button>
    <div class="subnav-content">
      
    <a href="prod.html">online service</a>
    <a href="sregister.php">REGISTER</a>
      <a href="slogin.php">LOGIN</a>
    </div>
  </div> 
  <div class="subnav">
    <button class="subnavbtn">ADMIN <i class="fa fa-caret-down"></i></button>
    <div class="subnav-content">
      <a href="adminlogin.php">LOGIN</a>
      
    </div>
    </div>
    <div class="subnav">
    <button class="subnavbtn"> <a href="logout.php">LOGOUT<i class="fa fa-caret-down"></i></a></button>
    
  </div>
</div>

  <article>  
<table style="width:100%"; border=1; background-color:#skyblue>
  <tr style="background-color:#skyblue">
    <th>ID</th>
    <th>product name</th>
    <th>product quantity</th> 
    <th>product price</th>
    <th>image</th>
    <th>product category</th>
    <th>buy</th>
  </tr>
  <?php while($row=mysqli_fetch_array($result)):?>
  <tr>
    <td><?php echo $row['productid'];?></td>
    <td><?php echo $row['productname'];?></td>
    <td><?php echo $row['productquantity'];?></td>
    <td><?php echo $row['productprice'];?></td>
    <td><?php echo $row['image'];?></td>
    <td><?php echo $row['productcategory'];?></td>
    
    <td>
    <form action="kugur.html" method="post">
<input type="hidden" name="business" value="faustin@gmail.com">
<input type="hidden" name="cmd" value="_xclick">
<input type="hidden" name="item_name" value="Premium Umbrella">
<input type="hidden" name="amount" value="50.00">
<input type="hidden" name="currency_code" value="frw">
<input type="hidden" name="undefined_quantity" value="1">
<input type="image" name="submit" border="0"
  src="https://www.paypalobjects.com/en_US/i/btn/btn_buynow_LG.gif"
  alt="Buy Now">
<img alt="" border="0" width="1" height="1"
  src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" >

</form>
            </td>
  </tr>
  <?php endwhile;?>
</table>
  </article>
  </section>
  <center>
    <footer class="footer text-center">
      <div class="footer-top">
        <div class="row">
          <div class="col-md-offset-3 col-md-6 text-center">
            <div class="widget">
              <h4 class="widget-title"> .</h4>
              <p><a href="#"><i class="fa fa-street-view" aria-hidden="true"></i></a> <b></b><br><a href="#"><i class="fa fa-map-marker" aria-hidden="true"></i></a><b> </b><br><br><a href="#"><i class="fa fa-envelope" aria-hidden="true"></i></a><b> </b><br><a href="#"><i class="fa fa-phone" aria-hidden="true"></i></a>  </p>
              
                <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
              
              <p class="copyright clear-float">
               
                <div class="credits">
                  
                  Designed by faustin</a>
                </div>
              </p>
            </div>
          </div>
        </div>
    </footer>
    </center>
  </body>
  </html>
