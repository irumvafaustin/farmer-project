
    <?php
  include_once 'config1.php';
  $sid=$_GET['sid'];
  $sql="DELETE FROM seller WHERE sid=$sid";
  mysqli_query($connection,$sql);
  header("location:seller.php");
  exit();
?>


