-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 22, 2021 at 03:08 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 7.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `register`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(20) NOT NULL,
  `adminemail` varchar(25) NOT NULL,
  `adminpassword` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `adminemail`, `adminpassword`) VALUES
(1, 'faustin@gmail.com', 'fausti123');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `cid` int(20) NOT NULL,
  `firstname` varchar(20) NOT NULL,
  `lastname` varchar(14) NOT NULL,
  `email` varchar(25) NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customer_id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(25) NOT NULL,
  `password` varchar(15) NOT NULL,
  `phone` int(20) NOT NULL,
  `gender` varchar(8) NOT NULL,
  `district` varchar(10) NOT NULL,
  `sector` varchar(10) NOT NULL,
  `cell` varchar(10) NOT NULL,
  `age` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `fregister`
--

CREATE TABLE `fregister` (
  `id` int(20) NOT NULL,
  `Fname` varchar(20) NOT NULL,
  `Lname` varchar(20) NOT NULL,
  `Email` varchar(20) NOT NULL,
  `Password` varchar(14) NOT NULL,
  `Gender` varchar(8) NOT NULL,
  `Category` varchar(15) NOT NULL,
  `Country` varchar(10) NOT NULL,
  `Provence` varchar(15) NOT NULL,
  `District` varchar(15) NOT NULL,
  `Sector` varchar(15) NOT NULL,
  `Cell` varchar(15) NOT NULL,
  `Village` varchar(15) NOT NULL,
  `phone` int(11) DEFAULT NULL,
  `age` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `fregister`
--

INSERT INTO `fregister` (`id`, `Fname`, `Lname`, `Email`, `Password`, `Gender`, `Category`, `Country`, `Provence`, `District`, `Sector`, `Cell`, `Village`, `phone`, `age`) VALUES
(13, 'irumva', 'faustin', 'faustin@gmail.com', '1234', 'male', 'medium', 'rwanda', 'western', 'nyabihu', 'bigogwe', 'kijote', 'busasamana', 788800683, 22),
(14, 'uwineza', 'divine', 'ange@gmail.com', 'ange', 'female', 'medium', 'rwanda', 'southern', 'kamonyi', 'gacurabwenge', 'gihinga', '', 78345276, 25);

-- --------------------------------------------------------

--
-- Table structure for table `goods`
--

CREATE TABLE `goods` (
  `gid` int(11) NOT NULL,
  `goodsname` varchar(20) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `category` varchar(20) NOT NULL,
  `seller_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ordergoods`
--

CREATE TABLE `ordergoods` (
  `ogid` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `category` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `orderproduct`
--

CREATE TABLE `orderproduct` (
  `order_id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `code` varchar(14) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `productid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orderproduct`
--

INSERT INTO `orderproduct` (`order_id`, `name`, `code`, `quantity`, `unit_price`, `price`, `productid`) VALUES
(77, '', '', 0, 0, 0, NULL),
(78, '', '', 0, 0, 0, NULL),
(79, '', '', 0, 0, 0, NULL),
(80, '', '', 0, 0, 0, NULL),
(81, '', '', 0, 0, 0, NULL),
(82, '', '', 0, 0, 0, NULL),
(83, '', '', 0, 0, 0, NULL),
(85, '', '', 0, 0, 0, NULL),
(88, '', '', 0, 0, 0, NULL),
(89, '', '', 0, 0, 0, NULL),
(90, '', '', 0, 0, 0, NULL),
(91, '', '', 0, 0, 0, NULL),
(92, '', '', 0, 0, 0, NULL),
(93, '', '', 0, 0, 0, NULL),
(94, '', '', 0, 0, 0, NULL),
(95, '', '', 0, 0, 0, NULL),
(96, '', '', 0, 0, 0, NULL),
(97, '', '', 0, 0, 0, NULL),
(98, '', '', 0, 0, 0, NULL),
(99, '', '', 0, 0, 0, NULL),
(100, '', '', 0, 0, 0, NULL),
(101, 'carrot', '00ct1', 1, 1500, 1500, NULL),
(102, 'carrot', '00ct1', 1, 1500, 1500, NULL),
(103, 'carrot', '00ct1', 1, 1500, 1500, NULL),
(104, 'carrot', '00ct1', 1, 1500, 1500, NULL),
(105, '', '', 0, 0, 0, NULL),
(106, '', '', 0, 0, 0, NULL),
(107, '', '', 0, 0, 0, NULL),
(108, '', '', 0, 0, 0, NULL),
(109, 'carrot', '00ct1', 1, 1500, 1500, NULL),
(110, 'carrot', '00ct1', 1, 1500, 1500, NULL),
(111, 'carrot', '00ct1', 1, 1500, 1500, NULL),
(112, 'carrot', '00ct1', 1, 1500, 1500, NULL),
(113, '', '', 0, 0, 0, NULL),
(114, '', '', 0, 0, 0, NULL),
(115, '', '', 0, 0, 0, NULL),
(116, '', '', 0, 0, 0, NULL),
(117, 'carrot', '00ct1', 1, 1500, 1500, NULL),
(118, 'carrot', '00ct1', 1, 1500, 1500, NULL),
(119, 'carrot', '00ct1', 1, 1500, 1500, NULL),
(120, 'carrot', '00ct1', 1, 1500, 1500, NULL),
(121, '', '', 0, 0, 0, NULL),
(122, '', '', 0, 0, 0, NULL),
(123, '', '', 0, 0, 0, NULL),
(124, '', '', 0, 0, 0, NULL),
(125, '', '', 0, 0, 0, NULL),
(126, '', '', 0, 0, 0, NULL),
(127, '', '', 0, 0, 0, NULL),
(128, '', '', 0, 0, 0, NULL),
(129, '', '', 0, 0, 0, NULL),
(130, '', '', 0, 0, 0, NULL),
(131, '', '', 0, 0, 0, NULL),
(132, '', '', 0, 0, 0, NULL),
(133, '', '', 0, 0, 0, NULL),
(134, '', '', 0, 0, 0, NULL),
(135, '', '', 0, 0, 0, NULL),
(136, '', '', 0, 0, 0, NULL),
(137, '', '', 0, 0, 0, NULL),
(138, '', '', 0, 0, 0, NULL),
(139, '', '', 0, 0, 0, NULL),
(140, '', '', 0, 0, 0, NULL),
(141, '', '', 0, 0, 0, NULL),
(142, '', '', 0, 0, 0, NULL),
(143, '', '', 0, 0, 0, NULL),
(144, '', '', 0, 0, 0, NULL),
(145, '', '', 0, 0, 0, NULL),
(146, '', '', 0, 0, 0, NULL),
(147, '', '', 0, 0, 0, NULL),
(148, '', '', 0, 0, 0, NULL),
(149, '', '', 0, 0, 0, NULL),
(150, '', '', 0, 0, 0, NULL),
(151, '', '', 0, 0, 0, NULL),
(152, '', '', 0, 0, 0, NULL),
(153, '', '', 0, 0, 0, NULL),
(154, '', '', 0, 0, 0, NULL),
(155, '', '', 0, 0, 0, NULL),
(156, '', '', 0, 0, 0, NULL),
(157, '', '', 0, 0, 0, NULL),
(158, '', '', 0, 0, 0, NULL),
(159, '', '', 0, 0, 0, NULL),
(160, '', '', 0, 0, 0, NULL),
(161, '', '', 0, 0, 0, NULL),
(162, '', '', 0, 0, 0, NULL),
(163, '', '', 0, 0, 0, NULL),
(164, '', '', 0, 0, 0, NULL),
(165, '', '', 0, 0, 0, NULL),
(166, '', '', 0, 0, 0, NULL),
(167, '', '', 0, 0, 0, NULL),
(168, '', '', 0, 0, 0, NULL),
(169, '', '', 0, 0, 0, NULL),
(170, '', '', 0, 0, 0, NULL),
(171, '', '', 0, 0, 0, NULL),
(172, '', '', 0, 0, 0, NULL),
(173, '', '', 0, 0, 0, NULL),
(174, '', '', 0, 0, 0, NULL),
(175, '', '', 0, 0, 0, NULL),
(176, '', '', 0, 0, 0, NULL),
(177, '', '', 0, 0, 0, NULL),
(178, '', '', 0, 0, 0, NULL),
(179, '', '', 0, 0, 0, NULL),
(180, '', '', 0, 0, 0, NULL),
(181, '', '', 0, 0, 0, NULL),
(182, '', '', 0, 0, 0, NULL),
(183, '', '', 0, 0, 0, NULL),
(184, '', '', 0, 0, 0, NULL),
(185, '', '', 0, 0, 0, NULL),
(186, 'carrot', 'C001', 1, 800, 800, NULL),
(187, 'carrot', 'C001', 2, 800, 800, NULL),
(188, 'carrot', 'C001', 2, 800, 800, NULL),
(189, 'carrot', 'C001', 2, 800, 800, NULL),
(190, 'carrot', 'C001', 2, 800, 800, NULL),
(191, '', '', 0, 0, 0, NULL),
(192, 'carrot', 'C001', 1, 800, 800, NULL),
(193, '', '', 0, 0, 0, NULL),
(194, 'carrot', 'C001', 1, 800, 800, NULL),
(195, 'carrot', 'C001', 2, 800, 800, NULL),
(196, 'carrot', 'C001', 3, 800, 800, NULL),
(197, 'carrot', 'C001', 4, 800, 800, NULL),
(198, 'carrot', 'C001', 5, 800, 800, NULL),
(199, 'carrot', 'C001', 6, 800, 800, NULL),
(200, '', '', 0, 0, 0, NULL),
(201, '', '', 0, 0, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `productivity`
--

CREATE TABLE `productivity` (
  `productid` int(20) NOT NULL,
  `productname` varchar(20) NOT NULL,
  `productquantity` int(14) NOT NULL,
  `productprice` varchar(10) NOT NULL,
  `image` varchar(20) NOT NULL,
  `productcategory` varchar(20) NOT NULL,
  `farmer_id` int(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `productivity`
--

INSERT INTO `productivity` (`productid`, `productname`, `productquantity`, `productprice`, `image`, `productcategory`, `farmer_id`) VALUES
(7, 'pineapple', 400, '15000', 'patatoes.jpg', 'fruits', 13),
(8, 'patatoes', 5000, '600000', 'patatoes.jpg', 'Carbohydrates', 13),
(11, 'ibinyomoro', 500, '60000', 'ibinyomoro.jpg', 'fruits', 13);

-- --------------------------------------------------------

--
-- Table structure for table `seller`
--

CREATE TABLE `seller` (
  `sid` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(25) NOT NULL,
  `password` varchar(15) NOT NULL,
  `phone` int(11) NOT NULL,
  `age` int(11) NOT NULL,
  `category` varchar(10) NOT NULL,
  `gender` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `seller`
--

INSERT INTO `seller` (`sid`, `name`, `email`, `password`, `phone`, `age`, `category`, `gender`) VALUES
(9, 'CYIZA Mugabo', 'mugabo@gmail.com', 'mugabo', 79000567, 2000, 'medium', 'male'),
(11, 'natete alexandere', 'alexandere@gmail.com', 'natete', 78544434, 1999, 'medium', 'male'),
(12, 'uwamahoro  angelique', 'ange@gmail.com', 'ange', 78544300, 2000, 'small', 'female');

-- --------------------------------------------------------

--
-- Table structure for table `tblproduct`
--

CREATE TABLE `tblproduct` (
  `id` int(8) NOT NULL,
  `name` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `image` text NOT NULL,
  `price` double(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblproduct`
--

INSERT INTO `tblproduct` (`id`, `name`, `code`, `image`, `price`) VALUES
(7, 'carrot', 'C001', 'product-images/carrot.jpg', 1000.00);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`cid`),
  ADD KEY `cid` (`cid`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `fregister`
--
ALTER TABLE `fregister`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `goods`
--
ALTER TABLE `goods`
  ADD KEY `gid` (`gid`),
  ADD KEY `seller_id` (`seller_id`);

--
-- Indexes for table `ordergoods`
--
ALTER TABLE `ordergoods`
  ADD PRIMARY KEY (`ogid`),
  ADD KEY `ogid` (`ogid`);

--
-- Indexes for table `orderproduct`
--
ALTER TABLE `orderproduct`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `productid` (`productid`),
  ADD KEY `productid_2` (`productid`);

--
-- Indexes for table `productivity`
--
ALTER TABLE `productivity`
  ADD PRIMARY KEY (`productid`),
  ADD KEY `productid` (`productid`),
  ADD KEY `id` (`farmer_id`);

--
-- Indexes for table `seller`
--
ALTER TABLE `seller`
  ADD PRIMARY KEY (`sid`),
  ADD KEY `sid` (`sid`);

--
-- Indexes for table `tblproduct`
--
ALTER TABLE `tblproduct`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `product_code` (`code`),
  ADD KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `cid` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `fregister`
--
ALTER TABLE `fregister`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `ordergoods`
--
ALTER TABLE `ordergoods`
  MODIFY `ogid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `orderproduct`
--
ALTER TABLE `orderproduct`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=202;

--
-- AUTO_INCREMENT for table `productivity`
--
ALTER TABLE `productivity`
  MODIFY `productid` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `seller`
--
ALTER TABLE `seller`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `tblproduct`
--
ALTER TABLE `tblproduct`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `goods`
--
ALTER TABLE `goods`
  ADD CONSTRAINT `goods_ibfk_1` FOREIGN KEY (`seller_id`) REFERENCES `seller` (`sid`);

--
-- Constraints for table `ordergoods`
--
ALTER TABLE `ordergoods`
  ADD CONSTRAINT `ordergoods_ibfk_1` FOREIGN KEY (`ogid`) REFERENCES `goods` (`gid`);

--
-- Constraints for table `orderproduct`
--
ALTER TABLE `orderproduct`
  ADD CONSTRAINT `orderproduct_ibfk_1` FOREIGN KEY (`productid`) REFERENCES `productivity` (`productid`);

--
-- Constraints for table `productivity`
--
ALTER TABLE `productivity`
  ADD CONSTRAINT `productivity_ibfk_1` FOREIGN KEY (`farmer_id`) REFERENCES `fregister` (`id`);

--
-- Constraints for table `tblproduct`
--
ALTER TABLE `tblproduct`
  ADD CONSTRAINT `tblproduct_ibfk_1` FOREIGN KEY (`id`) REFERENCES `productivity` (`productid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
